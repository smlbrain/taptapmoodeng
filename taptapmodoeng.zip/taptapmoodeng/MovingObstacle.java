public class MovingObstacle extends Obstacle {
    private int speed;

    public MovingObstacle(int startX, int startY, int speed) {
        super(startX, startY); // เรียกใช้งานจากคลาสแม่ Obstacle
        this.speed = speed;
    }

    @Override
    public void update() {
        x -= speed; // การเคลื่อนไหวของสิ่งกีดขวาง
    }
}

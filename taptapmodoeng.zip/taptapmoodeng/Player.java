import java.awt.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Player {
    private int x, y;
    private int width = 50, height = 50;
    private int gravity = 1;
    private int lift = -10;
    private int velocityY;
    private boolean isFlying;
    private Image playerImage; 

    public Player(int startX, int startY) {
        x = startX;
        y = startY;
        velocityY = 0;

       
        setImage("moodenggg.png" , width, height); 
    }

    public void setImage(String imagePath, int width2, int height2) {
        try {
            
            playerImage = ImageIO.read(new File(imagePath));
            width = playerImage.getWidth(null);
            height = playerImage.getHeight(null);
        } catch (IOException e) {
            System.out.println("ไม่สามารถโหลดภาพได้: " + imagePath);
            e.printStackTrace();
        }
    }

    public void update() {
        if (isFlying) {
            velocityY = lift;
        } else {
            velocityY += gravity;
        }
        y += velocityY;

        // ป้องกันไม่ให้ตัวละครตกจากหน้าจอ
        if (y > 500) {
            y = 500;
            velocityY = 0;
        } else if (y < 0) {
            y = 0;
            velocityY = 0;
        }
    }

    public void draw(Graphics g) {
        if (playerImage != null) {
            g.drawImage(playerImage, x, y, width, height, null); // วาดภาพของตัวละคร
        } else {
            g.setColor(Color.BLUE); // แสดงสี่เหลี่ยมสีน้ำเงินหากไม่พบภาพ
            g.fillRect(x, y, width, height);
        }
    }

    public void setFlying(boolean flying) {
        isFlying = flying;
    }

    public boolean intersects(Obstacle obstacle) {
        Rectangle playerBounds = new Rectangle(x, y, width, height);
        Rectangle obstacleBounds = new Rectangle(obstacle.getX(), obstacle.getY(), obstacle.getWidth(), obstacle.getHeight());
        return playerBounds.intersects(obstacleBounds);
    }

    public boolean intersects(Item item) {
        Rectangle playerBounds = new Rectangle(x, y, width, height);
        Rectangle itemBounds = new Rectangle(item.getX(), item.getY(), item.getWidth(), item.getHeight());
        return playerBounds.intersects(itemBounds);
    }
}

import java.awt.*;
import javax.swing.ImageIcon;

public class Item {
    private int x, y;
    private int width = 50, height = 50; // ขนาดเริ่มต้น
    private int speed = 5;
    private Image itemImage; // ตัวแปรสำหรับเก็บภาพ Item

    public Item(int startX, int startY) {
        x = startX;
        y = startY;

        // โหลดภาพเริ่มต้นของ Item และตั้งขนาด
        setImage("watermelon.png", width, height); // กำหนดขนาดเริ่มต้นที่ต้องการ
    }

    public void setImage(String imagePath, int newWidth, int newHeight) {
        try {
            // ใช้ ImageIcon เพื่อโหลดภาพและปรับขนาด
            itemImage = new ImageIcon(imagePath).getImage();
            itemImage = itemImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            
            // ตั้งค่า width และ height ของไอเท็มตามภาพที่กำหนด
            width = newWidth;
            height = newHeight;
            
            System.out.println("ภาพ Item โหลดสำเร็จ: " + imagePath);
        } catch (Exception e) {
            System.out.println("ไม่สามารถโหลดภาพ Item ได้: " + imagePath);
            e.printStackTrace();
        }
    }

    public void update() {
        x -= speed; // เคลื่อนที่จากขวาไปซ้าย
    }

    public void draw(Graphics g) {
        if (itemImage != null) {
            g.drawImage(itemImage, x, y, width, height, null); // วาดภาพ Item
        } else {
            g.setColor(Color.YELLOW); // แสดงสี่เหลี่ยมสีเหลืองหากไม่พบภาพ
            g.fillRect(x, y, width, height);
        }
    }

    public boolean isOutOfScreen() {
        return x + width < 0;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}

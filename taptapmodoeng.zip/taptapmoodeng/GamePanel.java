import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    private Timer timer;
    private Player player;
    private ArrayList<Obstacle> obstacles;
    private ArrayList<Item> items;
    private int score;
    private boolean isGameOver;
    private JButton startButton;
    private Image backgroundImage; 

    public GamePanel() {
        
        this.setBackground(Color.CYAN);
        player = new Player(100, 300);
        obstacles = new ArrayList<>();
        items = new ArrayList<>();
        score = 0;
        isGameOver = false;
        
        this.setFocusable(true);
        this.addKeyListener(this);
        
        timer = new Timer(16, this);

       
        loadBackgroundImage("moodengbg.jpg");

        
        startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.setPreferredSize(new Dimension(200, 50));
        startButton.addActionListener(e -> startGame());
        
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 200));
        this.add(startButton);

        this.revalidate();
        this.repaint();
    }

    private void loadBackgroundImage(String imagePath) {
        try {
            backgroundImage = ImageIO.read(new File(imagePath)); // โหลดภาพพื้นหลัง
            if (backgroundImage == null) {
                System.out.println("ไม่สามารถโหลดภาพพื้นหลังได้จาก: " + imagePath);
            } else {
                System.out.println("ภาพพื้นหลังโหลดสำเร็จจาก: " + imagePath);
            }
        } catch (IOException e) {
            System.out.println("ข้อผิดพลาดในการโหลดภาพพื้นหลังจาก: " + imagePath);
            e.printStackTrace();
        }
    }
    public void startMenu() {
        // แสดงปุ่มเมื่อเริ่มเกมครั้งแรก
        startButton.setVisible(true);
    }

    private void resetGame() {
       
        player = new Player(100, 300);  
        obstacles.clear();              
        items.clear();                 
        score = 0;                       
        isGameOver = false;              
    }

    public void startGame() {
        resetGame();
        startButton.setVisible(false);
        timer.start();
        spawnObstacle();
        spawnItem();
    }

    private void spawnObstacle() {
        Timer obstacleSpawner = new Timer(2000, e -> {
            if (!isGameOver) {
                obstacles.add(new Obstacle(800, (int)(Math.random() * 400) + 100));

                obstacles.add(new MovingObstacle(900, 300, 5));
            }
        });
        obstacleSpawner.start();
    }

    private void spawnItem() {
        Timer itemSpawner = new Timer(3000, e -> {
            if (!isGameOver) {
                items.add(new Item(800, (int)(Math.random() * 400) + 100));
            }
        });
        itemSpawner.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

       
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), null);
        } else {
        
        }

       
        if (!isGameOver && timer.isRunning()) {
            player.draw(g);

            for (Obstacle obstacle : obstacles) {
                obstacle.draw(g);
            }

            for (Item item : items) {
                item.draw(g);
            }

            g.setColor(Color.BLACK);
            g.drawString("Score: " + score, 0, 10);
        }

        // แสดงข้อความ "Game Over" และปุ่ม Start เมื่อเกมจบ
        if (isGameOver) {
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.setColor(Color.RED);
            g.drawString("Game Over", 300, 300); // วาดข้อความ Game Over ตรงกลาง

            g.setFont(new Font("Arial", Font.PLAIN, 24));
            g.setColor(Color.BLACK);
            g.drawString("You Score: " + score, 320, 340);


            startButton.setText("Play Again"); // เปลี่ยนข้อความปุ่มเป็น "Play Again"
            startButton.setLocation(300, 350); // ตั้งตำแหน่งปุ่มให้อยู่ด้านล่างข้อความ
            startButton.setVisible(true);      // แสดงปุ่มเมื่อเกมจบ
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isGameOver) {
            player.update();

            for (int i = 0; i < obstacles.size(); i++) {
                Obstacle obstacle = obstacles.get(i);
                obstacle.update();

                if (obstacle.isOutOfScreen()) {
                    obstacles.remove(i);
                    i--;
                } else if (player.intersects(obstacle)) {
                    isGameOver = true;
                    timer.stop();
                }
            }

            for (int i = 0; i < items.size(); i++) {
                Item item = items.get(i);
                item.update();

                if (item.isOutOfScreen()) {
                    items.remove(i);
                    i--;
                } else if (player.intersects(item)) {
                    items.remove(i);
                    score += 10;
                    i--;
                }
            }

            score += 1;
        }
        
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE && !isGameOver) {
            player.setFlying(true);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            player.setFlying(false);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}

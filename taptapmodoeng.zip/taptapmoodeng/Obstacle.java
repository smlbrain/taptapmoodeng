import java.awt.*;
import javax.swing.ImageIcon; 


public class Obstacle {
    protected int x, y;
    private int width = 50, height = 200; 
    private int speed = 5;
    private Image obstacleImage; 

    public Obstacle(int startX, int startY) {
        x = startX;
        y = startY;

      
        setImage("zapper.png", 50, 150); 
    }

    public void setImage(String imagePath, int newWidth, int newHeight) {
        try {
           
            obstacleImage = new ImageIcon(imagePath).getImage();

            
            obstacleImage = obstacleImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            width = newWidth;
            height = newHeight;
            
            System.out.println("ภาพ Obstacle โหลดสำเร็จ: " + imagePath);
        } catch (Exception e) {
            System.out.println("ไม่สามารถโหลดภาพ Obstacle ได้: " + imagePath);
            e.printStackTrace();
        }
    }

    public void update() {
        x -= speed; // เคลื่อนที่จากขวาไปซ้าย
    }

    public void draw(Graphics g) {
        if (obstacleImage != null) {
            g.drawImage(obstacleImage, x, y, width, height, null); // วาดภาพ Obstacle
        } else {
            g.setColor(Color.RED); // หากไม่มีภาพ จะแสดงสี่เหลี่ยมสีแดงแทน
            g.fillRect(x, y, width, height);
        }
    }

    public boolean isOutOfScreen() {
        return x + width < 0;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
